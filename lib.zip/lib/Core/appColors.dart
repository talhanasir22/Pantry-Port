import 'package:flutter/material.dart';

class AppColors{

  static Color bgColor = Color(0xffF6C315);
  static Color shadowColor = Color(0xFFfef0dc);
  static Color theme = Color(0xffFFFEF1);

}